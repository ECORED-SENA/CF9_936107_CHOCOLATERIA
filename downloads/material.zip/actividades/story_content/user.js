function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Xa7x6e5xmv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

